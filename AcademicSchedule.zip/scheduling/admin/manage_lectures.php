<?php include 'db_connect.php' ?>
<?php
if(isset($_GET['lecture_id'])){
	$qry = $conn->query("SELECT * FROM lectures where lecture_id=".$_GET['lecture_id'])->fetch_array();
	foreach($qry as $k =>$v){
		$$k = $v;
	}
}

?>
<div class="container-fluid">
	<form action="" id="manage-lectures">
		<div id="msg"></div>
				<input type="hidden" name="lecture_id" value="<?php echo isset($_GET['lecture_id']) ? $_GET['lecture_id']:'' ?>" class="form-control">
		<div class="row form-group">
		<div class="col-md-4">
			<label class="control-label">Lecture ID</label>
			<input type="text" name="lecture_id" class="form-control" value="<?php echo isset($lecture_id) ? $lecture_id:'' ?>" >
		</div>
		<div class="row form-group">
			<div class="col-md-4">
				<label class="control-label">Lecture Name</label>
				<input type="text" name="lecture_name" class="form-control" value="<?php echo isset($lecture_name) ? $lecture_name:'' ?>" required>
			</div>
		<div class="row form-group">
			<div class="col-md-4">
				<label class="control-label">Email</label>
				<input type="email" name="email" class="form-control" value="<?php echo isset($email) ? $email:'' ?>" required>
			</div>
			<div class="col-md-4">
				<label class="control-label">Contact</label>
				<input type="text" name="contact" class="form-control" value="<?php echo isset($contact) ? $contact:'' ?>" required>
			</div>
	</form>
</div>

<script>
// $('#manage-lectures').submit(function(e){
//     e.preventDefault();
//     $.ajax({
//         url:'ajax.php?action=save_lectures',
//         method:'POST',
//         data:$(this).serialize(),
//         success:function(resp){
//             if(resp == 1){
//                 console.log("Data successfully saved.");
//                 setTimeout(function(){
//                     location.reload();
//                 },1000);
//             }else if(resp == 2){
//                 $('#msg').html('<div class="alert alert-danger"> ERROR .</div>');
//             }else{
//                 console.log(resp);
//                 console.log("Error saving data: " + resp);
//             }
//         },
//         error: function(xhr, status, error) {
//             console.log(xhr.responseText);
//             console.log("Error saving data: " + error);
//         }
//     });
// });
$('#manage-lectures').submit(function(e){
		e.preventDefault()
		start_load()
		$('#msg').html('')
		$.ajax({
			url:'ajax.php?action=save_lectures',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully saved",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else{
                console.log(resp); // log the response to the console for debugging
                alert_toast("Error saving data: " + resp,'error') // show an error message to the user
                end_load();
           		}
			}
		})
	})
</script>