<?php include 'db_connect.php' ?>
<?php
if(isset($_GET['id'])){
	$qry = $conn->query("SELECT * FROM faculty where id=".$_GET['id'])->fetch_array();
	foreach($qry as $k =>$v){
		$$k = $v;
	}
}

?>
<div class="container-fluid">
	<form action="" id="manage-faculty">
		<!-- <div id="msg"></div>
				<input type="hidden" name="id" value="<?php echo isset($_GET['id_no']) ? $_GET['id_no']:'' ?>" class="form-control"> -->
		<div class="row form-group">
			<div class="col-md-4">
					<label class="control-label">ID Course</label>
					<!-- <input type="text" name="id" class="form-control" value="<?php echo isset($id) ? $id:'' ?>" > -->
					<!-- <select name="id" id="" class="custom-select" value="<?php echo isset($id) ? $id:'' ?>">
							<option value="1" <?php echo isset($id) && $id == 1 ? 'selected' : ''  ?>> 1 - IT Batch 20222 </option>
							<option value="2" <?php echo isset($id) && $id == 2 ? 'selected' : ''  ?>> 2 - IS Batch 20222 </option>
							<option value="3" <?php echo isset($id) && $id == 3 ? 'selected' : ''  ?>> 3 - VCD Batch 2022 </option> -->
					<select name="id" required="" class="custom-select" id="">
					<option <?php echo isset($id) && $id == '1' ? 'selected' : '' ?>> 1 - IT Bacth 20222 </option>
					<option <?php echo isset($id) && $id == '2' ? 'selected' : '' ?>> 2 - IS Batch 20222 </option>
					<option <?php echo isset($id) && $id == '3' ? 'selected' : '' ?>> 3 - VCD Bacth 20222 </option>
				</select>
						</select>
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-4">
						<label class="control-label">ID No.</label>
						<input type="text" name="id_no" class="form-control" value="<?php echo isset($id_no) ? $id_no:'' ?>" >
						<small><i>Leave this blank if you want to a auto generate ID no.</i></small>
					</div>
		</div>
		<div class="row form-group">
			<!-- <div class="col-md-4">
				<label class="control-label">Last Name</label>
				<input type="text" name="lastname" class="form-control" value="<?php echo isset($lastname) ? $lastname:'' ?>" required>
			</div> -->
			<div class="col-md-4">
				<label class="control-label">First Name</label>
				<input type="text" name="firstname" class="form-control" value="<?php echo isset($firstname) ? $firstname:'' ?>" required>
			</div>
			<div class="col-md-4">
				<label class="control-label">Middle Name</label>
				<input type="text" name="middlename" class="form-control" value="<?php echo isset($middlename) ? $middlename:'' ?>">
			</div>
			<div class="col-md-4">
				<label class="control-label">Last Name</label>
				<input type="text" name="lastname" class="form-control" value="<?php echo isset($lastname) ? $lastname:'' ?>" required>
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-4">
				<label class="control-label">Email</label>
				<input type="email" name="email" class="form-control" value="<?php echo isset($email) ? $email:'' ?>" required>
			</div>
			<div class="col-md-4">
				<label class="control-label">Contact #</label>
				<input type="text" name="contact" class="form-control" value="<?php echo isset($contact) ? $contact:'' ?>" required>
			</div>
			<div class="col-md-4">
				<label class="control-label">Gender</label>
				<select name="gender" required="" class="custom-select" id="">
					<option <?php echo isset($gender) && $gender == 'Male' ? 'selected' : '' ?>>Male</option>
					<option <?php echo isset($gender) && $gender == 'Female' ? 'selected' : '' ?>>Female</option>
				</select>
			</div>
		</div>
		<div class="row form-group">
			<div class="col-md-12">
				<label class="control-label">Address</label>
				<textarea name="address" class="form-control"><?php echo isset($address) ? $address : '' ?></textarea>
			</div>
		</div>
	</form>
</div>

<script>
$('#manage-faculty').submit(function(e){
    e.preventDefault()
    start_load()
    $.ajax({
        url:'ajax.php?action=save_faculty',
        method:'POST',
        data:$(this).serialize(),
        success:function(resp){
            if(resp == 1){
                alert_toast("Data successfully saved.",'success')
                setTimeout(function(){
                    location.reload()
                },1000)
            }else if(resp == 2){
                $('#msg').html('<div class="alert alert-danger">ID No already existed.</div>')
                end_load();
            }else{
                console.log(resp); // log the response to the console for debugging
                alert_toast("Error saving data: " + resp,'error') // show an error message to the user
                end_load();
            }
        },
        error: function(xhr, status, error) {
            console.log(xhr.responseText); // log the error message to the console for debugging
            alert_toast("Error saving data: " + error,'error') // show an error message to the user
            end_load();
        }
    });
});
</script>