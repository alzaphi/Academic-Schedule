<?php include 'db_connect.php' ?>
<?php
if(isset($_GET['lecture_id'])){
	$qry = $conn->query("SELECT *, CONCAT(lecture_id,', ',lecture_name,', ',email,', ',contact) as name FROM lectures where lecture_id=".$_GET['lecture_id'])->fetch_array();
	foreach($qry as $k =>$v){
		$$k = $v;
	}
}

?>
<div class="container-fluid">
	<p>Name: <b><?php echo ucwords ($lecture_name) ?></b></p>
	<p>Email: </i> <b><?php echo $email?> </b></p>
	<p>Contact: </i> <b><?php echo $contact ?></b></p>
	<hr class="divider">
</div>

<div class="modal-footer display">
	<div class="row">
		<div class="col-md-12">
			<button class="btn float-right btn-secondary" type="button" data-dismiss="modal">Close</button>
		</div>
	</div>
</div>
<style>
	p{
		margin:unset;
	}
	#uni_modal .modal-footer{
		display: none;
	}
	#uni_modal .modal-footer.display {
		display: block;
	}
</style>
<script>
    $('#edit').click(function(){
		uni_modal('Edit Lectures','manage_lectures.php?lecture_id=<?php echo $id ?>','mid-large')
	})
	$('#delete_lectures').click(function(){
		_conf("Are you sure to delete this schedule?","delete_lectures",[$(this).attr('data-lecture_id')])
	})
	
	function delete_lectures($lecture_id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_lectures',
			method:'POST',
			data:{lecture_id:$lecture_id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)
				}else{
                console.log(resp); // log the response to the console for debugging
                alert_toast("Error saving data: " + resp,'error') // show an error message to the user
                end_load();
				}
			}
		})
	}
	
</script>