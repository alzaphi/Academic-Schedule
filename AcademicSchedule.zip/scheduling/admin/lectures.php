<?php include
('db_connect.php');?>

<div class="container-fluid">
<style>
	input[type=checkbox]
{
  /* Double-sized Checkboxes */
  -ms-transform: scale(1.5); /* IE */
  -moz-transform: scale(1.5); /* FF */
  -webkit-transform: scale(1.5); /* Safari and Chrome */
  -o-transform: scale(1.5); /* Opera */
  transform: scale(1.5);
  padding: 10px;
}
</style>
	<div class="col-lg-12">
		<div class="row mb-4 mt-4">
			<div class="col-md-12">
				
			</div>
		</div>
		<div class="row">
			<!-- FORM Panel -->

			<!-- Table Panel -->
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<b>Lecture List</b>
						<span class="">
							<button class="btn btn-primary btn-block btn-sm col-sm-2 float-right" type="button" id="new_lectures">
					<i class="fa fa-plus"></i> Add</button>
				</span>
					</div>
					<div class="card-body">
						
						<table class="table table-bordered table-condensed table-hover">
							<colgroup>
								<col width="5%">
								<col width="20%">
								<col width="30%">
								<col width="20%">
								<col width="10%">
								<col width="15%">
							</colgroup>
							<thead>
								<tr>
									<th class="text-center">No</th>
									<th class="">Lecture ID</th>
									<th class="">Name</th>
									<th class="">Email</th>
									<th class="">Contact</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<!-- <tbody>
								<?php 
								$i = 1;
								$lectures =  $conn->query("SELECT *,concat('lecture_id,', ',lecture_name,') as name from lectures order by concat('lecture_id,', ',lecture_name,') asc");
								while($row=$lectures->fetch_assoc()):
								?>
								<tr>
									
									<td class="text-center"><?php echo $i++ ?></td>
									<td class="">
										 <p><b><?php echo $row['lecture_id'] ?></b></p>
										 
									</td>
									<td class="">
										 <p><b><?php echo ucwords($row['lecture_name']) ?></b></p>
										 
									</td>
									<td class="">
										 <p><b><?php echo $row['email'] ?></b></p>
									</td>
									<td class="text-right">
										 <p><b><?php echo $row['contact'] ?></b></p>
										 
									</td>
									<td class="text-center">
										<button class="btn btn-sm btn-outline-primary view_lectures" type="button" data-lecture_id="<?php echo $row['lecture_id'] ?>" data-name="<?php echo $row['lecture_name'] ?>" data-email="<?php echo $row['email'] ?>" data-contact="<?php echo $row['contact'] ?>" >View</button>
										<button class="btn btn-sm btn-outline-primary edit_lectures" type="button" data-lecture_id="<?php echo $row['lecture_id'] ?>" data-name="<?php echo $row['lecture_name'] ?>" data-email="<?php echo $row['email'] ?>" data-contact="<?php echo $row['contact'] ?>" >Edit</button>
										<button class="btn btn-sm btn-outline-danger delete_lectures" type="button" data-lecture_id="<?php echo $row['lecture_id'] ?>">Delete</button>
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody> -->
                            <tbody>
                                <?php 
								$i = 1;
								$lectures =  $conn->query("SELECT *,concat('lecture_id,', ',lecture_name,') as name from lectures order by concat('lecture_id,', ',lecture_name,') asc");
								while($row=$lectures->fetch_assoc()):
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class="">
										 <p><b><?php echo $row['lecture_id'] ?></b></p>
										 
									</td>
									<td class="">
										 <p><b><?php echo ucwords($row['lecture_name']) ?></b></p>
										 
									</td>
									<td class="">
										 <p><b><?php echo $row['email'] ?></b></p>
									</td>
									<td class="text-right">
										 <p><b><?php echo $row['contact'] ?></b></p>
										 
									</td>
									<td class="text-center">
                                        <button class="btn btn-sm btn-outline-primary view_lectures" type="button" data-lecture_id="<?php echo $row['lecture_id'] ?>" data-name="<?php echo $row['lecture_name'] ?>" data-email="<?php echo $row['email'] ?>" data-contact="<?php echo $row['contact'] ?>" >View</button>
										<button class="btn btn-sm btn-outline-primary edit_lectures" type="button" data-lecture_id="<?php echo $row['lecture_id'] ?>" data-name="<?php echo $row['lecture_name'] ?>" data-email="<?php echo $row['email'] ?>" data-contact="<?php echo $row['contact'] ?>" >Edit</button>
										<button class="btn btn-sm btn-outline-danger delete_lectures" type="button" data-lecture_id="<?php echo $row['lecture_id'] ?>">Delete</button>
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<style>
	
	td{
		vertical-align: middle !important;
	}
	td p{
		margin: unset
	}
	img{
		max-width:100px;
		max-height: :150px;
	}
</style>
<script>
	$(document).ready(function(){
		$('table').dataTable()
	})
	$('#new_lectures').click(function(){
		uni_modal("New Entry","manage_lectures.php",'mid-large')
	})
	$('.view_lectures').click(function(){
		uni_modal("Lectures Details","view_lectures.php?lecture_id="+$(this).attr('data-lecture_id'),'')
		
	})
    $('.edit_lectures').click(function(){
		uni_modal("Edit Lectures","manage_lectures.php?lecture_id="+$(this).attr('data-lecture_id'),'mid-large')
		
	})
    $('.delete_lectures').click(function(){
		_conf("Are you sure to delete this topic?","delete_lectures",[$(this).attr('data-lecture_id')],'mid-large')
	})
	function delete_lectures($lecture_id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_lectures',
			method:'POST',
			data:{lecture_id:$lecture_id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>